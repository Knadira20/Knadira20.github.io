---
name: Luminous Clarity
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#49473f'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#7a776e'
  outline-variant: '#cac6bc'
  surface-tint: '#615f51'
  primary: '#615f51'
  on-primary: '#ffffff'
  primary-container: '#fef9e7'
  on-primary-container: '#757264'
  inverse-primary: '#cbc7b6'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fdd028'
  on-secondary-container: '#6f5900'
  tertiary: '#595f64'
  on-tertiary: '#ffffff'
  tertiary-container: '#f4faff'
  on-tertiary-container: '#6d7378'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e7e3d1'
  primary-fixed-dim: '#cbc7b6'
  on-primary-fixed: '#1d1c11'
  on-primary-fixed-variant: '#49473a'
  secondary-fixed: '#ffe083'
  secondary-fixed-dim: '#eec214'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#dde3e8'
  tertiary-fixed-dim: '#c1c7cc'
  on-tertiary-fixed: '#161c20'
  on-tertiary-fixed-variant: '#41484c'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Space Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-lg: 2rem
  margin: 1.25rem
  margin-md: 2.5rem
  margin-lg: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies refined minimalism, architectural restraint, and warm professionalism. Designed specifically for high-impact personal portfolios, it strikes a deliberate balance between clinical structure and human warmth. 

The aesthetic communicates quiet authority: generous negative space, purposeful typographic cadence, and restrained accentuation. Instead of loud animations or heavy visual ornamentation, the system relies on pristine alignment, subtle atmospheric warmth, and decisive micro-interactions. The intended emotional response is immediate trust, effortless readability, and an impression of meticulous craftsmanship.

## Colors

The palette establishes a soft, sunlit clarity using warm off-whites, neutral light grays, and precise golden-amber highlights anchored by charcoal typography.

- **Canvas & Surfaces:**
  - Base canvas: `#FFFFFF`
  - Subtle secondary surface / layout framing: `#F8F9FA`
  - Subtle divider / border line: `#EAECEF`
- **Tonal Accents:**
  - Primary tint: Soft pastel yellow (`#FEF9E7`, with `#FFF9C4` for hover highlights) serves as non-intrusive container backgrounds, badge surfaces, and focus washes.
  - Interactive accent: Muted amber / soft gold (`#E5BA00`) powers call-to-action buttons, active nav indicators, and key focus outlines. Its text pairing is strictly `#222222` to ensure AAA contrast compliance.
- **Typography & Neutrals:**
  - Primary body and headings: Deep dark charcoal (`#222222`) ensures optimal contrast while avoiding the harshness of `#000000`.
  - Secondary metadata & subtitles: Neutral muted charcoal (`#666666`).
  - Tertiary / subtle icons: Soft slate (`#999999`).

## Typography

The type scale combines a clean geometric sans with high structural clarity for headlines, alongside utilitarian neutral body text.

- **Headlines:** Set in an engineered geometric sans to deliver crisp, modern character, architectural sharpness, and distinct identity for titles and case study intros.
- **Body & Labels:** Set in Inter for peak legibility, precise tabular metrics, and smooth reading flow across complex project breakdowns and metadata.
- **Handling & Rhythm:** Maintain strict relative line-heights. Display elements use tighter tracking (`-0.02em` to `-0.03em`) to anchor attention, while captions and small labels expand slightly (`+0.01em` to `+0.04em`) to safeguard visual scanability.

## Layout & Spacing

The layout philosophy centers on a responsive 12-column grid constrained to a maximum content width of `1200px` on desktop, ensuring focused sightlines for case studies and curated works.

- **Breakpoints & Grids:**
  - **Desktop (1024px+):** 12 columns, `2rem` gutters, outer canvas margin `4rem`.
  - **Tablet (768px – 1023px):** 8 columns, `1.5rem` gutters, outer canvas margin `2.5rem`.
  - **Mobile (Below 768px):** 4 columns, `1rem` gutters, outer canvas margin `1.25rem`.
- **Rhythm & Structure:**
  - Vertical rhythm relies on multi-tiered section dividers spanning `4rem` to `6rem` to create comfortable visual pacing between portfolio chapters.
  - Sub-grid compositions keep micro-spacing compact (`space-xs` through `space-md`), creating cohesive clusters of text, tags, and action buttons within larger expanses of whitespace.

## Elevation & Depth

This system avoids heavy drop shadows, instead using razor-thin outlines paired with precise, micro-diffused ambient drop offsets.

- **Surfaces & Borders:** Baseline hierarchy relies on low-contrast hairline borders (`1px solid #EAECEF`) over pure `#FFFFFF` or `#F8F9FA` fields.
- **Resting Elevation:** Cards sit flat or with subtle separation: `0 1px 3px rgba(34, 34, 34, 0.04), 0 1px 2px rgba(34, 34, 34, 0.02)`.
- **Interactive Elevation:** On hover, project cards lift minimally using a crisp, warm-tinted shadow: `0 8px 24px rgba(34, 34, 34, 0.06), 0 2px 6px rgba(229, 186, 0, 0.08)`, combined with a `-2px` vertical translation.
- **Modals & Overlays:** Elevated dialogs and sticky floating bars utilize `0 16px 32px rgba(34, 34, 34, 0.08)` complemented by a backdrop blur (`blur(12px)`) on semi-translucent surfaces (`rgba(255, 255, 255, 0.92)`).

## Shapes

The shape system adopts a soft, disciplined geometry (`roundedness: 1`). 

- Default elements (buttons, input fields, tags) feature a tight `0.25rem` (4px) corner radius.
- Cards, containers, and visual viewports utilize `rounded-lg` (`0.5rem` / 8px).
- Modals, large featured showcases, and hero media containers use `rounded-xl` (`0.75rem` / 12px).
- This restrained curvature avoids overly rounded, casual styling, maintaining an architectural, modern feel that frames portfolio work with precision.

## Components

### Buttons
- **Primary:** Solid `#E5BA00` fill with `#222222` label text, `0.25rem` border radius, padding `0.75rem 1.5rem`. Subtle active depression on click. No heavy borders.
- **Secondary:** Transparent background with `1px solid #EAECEF`, `#222222` label. Hover states shift background to `#FEF9E7` and border color to `#E5BA00`.
- **Ghost:** Text-only in `#222222` with a trailing arrow icon; hover underlines with a 2px `#E5BA00` rule.

### Navigation Bar
- Minimalist sticky horizontal bar floating at the top with a backdrop blur (`rgba(255, 255, 255, 0.85)`).
- Hairline bottom border (`#EAECEF`).
- Contains monogram / logotype, concise section links with interactive active states marked by a discrete `#E5BA00` dot underneath, and an available-for-work status pill (`#FEF9E7` fill, amber indicator dot).

### Cards (Project & Experience)
- Constructed with `#FFFFFF` background, wrapped in a `1px solid #EAECEF` stroke, and `0.5rem` radius.
- Generous internal padding (`space-lg` to `space-xl`).
- Hover states transition border to `#E5BA00` (50% opacity) and trigger the ambient crisp shadow.

### Chips & Badges
- Category filters and tech-stack pills use `#F8F9FA` background with a subtle `#EAECEF` border.
- Highlighted/active chips shift to `#FEF9E7` fill, `#E5BA00` border, and `#222222` font weight `500`.

### Form Controls & Inputs
- Text inputs and textareas use `#FFFFFF` fill with `1px solid #EAECEF`.
- Padding set to `0.75rem 1rem`. Focus state removes default browser rings and renders a clean `1px solid #E5BA00` outline with a `2px` soft yellow glow (`rgba(229, 186, 0, 0.15)`).

### Selection Controls
- **Checkboxes & Radios:** Unchecked state uses `#FFFFFF` with `1.5px solid #CCCCCC`. Checked state fills `#E5BA00` with `#222222` checkmark/indicator.

### Professional Footer
- Grounded on `#F8F9FA` with a top hairline border (`#EAECEF`).
- Structured in clean columns: Direct contact CTA, social indices, resume links, and copyright timestamp.
- Back-to-top micro-button styled with secondary button tokens.